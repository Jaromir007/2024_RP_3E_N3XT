# 2024\_RP\_3E\_N3XT
N3XT - Jaromír Obitko, Matěj Kryštof Zich, Michal Drápal

clipper-test obsahuje testovací C++, v cpp je kód kompilovaný do wasm. 

Máme ještě jeden repozitář s částí ve frameworku Django (kterou měl na starosti hlavně Michal D.), ale nestihli jsme ji dokončit v termínu, proto přikládám pouze odkaz: [2024\_RP\_3E\_N3XT\_django](https://github.com/Jaromir007/2024_RP_3E_N3XT_django)

[Prezentace 1](https://docs.google.com/presentation/d/1JVJeRS3xDeapZDWGwykHUfxAE9_kRY2ILhCKTlxtKJ4/edit?usp=sharing)

[Prezentace 2](https://docs.google.com/presentation/d/1lx2NM3tQIRyjscBn8-69G_tDTQ_a8WnBYybl524v9OQ/edit?usp=sharing)

[Obhajoba SOČ](https://docs.google.com/presentation/d/1NoC7e-Ibjq2_CpCtp5y8QGFANqurjdLrVnFvech1Zno/edit?usp=sharing)

